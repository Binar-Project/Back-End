const Event = require("./eventModel");
const User = require("./userModel");

module.exports = { Event, User };
